import tkinter as tk
from ec.edu.espe.Strategy.view.sorting_view import SortingView

if __name__ == "__main__":
    root = tk.Tk()
    app = SortingView(root)
    root.mainloop()
